public class Carro {
    public String marca;
    public String modelo;
    public int ano;
    public String cor;
    public int cilindro;
    public String cavalo;
    public String velocidade_maxima;
    public int marcha;
    public int porta;
    public String zero_a_cem;
    public String cambio;
    public boolean acelerando = true;
    public boolean freando = false;
    public boolean mudar_marcha = true;

    public void acelerar() {
        if (acelerando)
            System.out.println(modelo + " " + marca + " = Acelera " + "Vrummmm");
    }

    public void frear() {
        if (!freando)
            System.out.println(modelo + " " + marca + " = Freia " + "Skrrrrr");
    }
    public void mudar() {
        if (mudar_marcha)
            System.out.println(modelo + " " + marca + " = Troca a marcha " + "Stututututu");
    }
    public void info(){
        System.out.println("Marca:" + " " + marca);
        System.out.println("Modelo:" + " " + modelo);
        System.out.println("Ano:" + " " + ano);
        System.out.println("Pintura:" + " " + cor);
        System.out.println("Cilíndros:" + " " + cilindro);
        System.out.println("Potência:" + " " + cavalo);
        System.out.println("Velocidade Máxima:" + " " + velocidade_maxima);
        System.out.println("Quantidade de marchas:" + " " + marcha);
        System.out.println("Portas:" + " " + porta);
        System.out.println("0 - 100:" + " " + zero_a_cem);
        System.out.println("Câmbio:" + " " + cambio);
        System.out.println("                                           ");
        System.out.println("---=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=---");
        System.out.println("                                           ");
    }
}