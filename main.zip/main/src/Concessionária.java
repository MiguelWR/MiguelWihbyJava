public class Concessionária {
    public static void main(String[] args) {
        Carro carro1 = new Carro();

        carro1.marca = "Mercedes";
        carro1.modelo = "A45";
        carro1.ano = 2020;
        carro1.cor = "Vermelho";
        carro1.cilindro = 4;
        carro1.cavalo = "421 cavalos";
        carro1.velocidade_maxima = "270 km/h";
        carro1.marcha = 8;
        carro1.porta = 4;
        carro1.zero_a_cem = "3.9 segundos";
        carro1.cambio = "Automático";
        carro1.info();

        Carro carro2 = new Carro();

        carro2.marca = "Audi";
        carro2.modelo = "R8";
        carro2.ano = 2018;
        carro2.cor = "Preto";
        carro2.cilindro = 10;
        carro2.cavalo = "562 cavalos";
        carro2.velocidade_maxima = "320 km/h";
        carro2.marcha = 7;
        carro2.porta = 2;
        carro2.zero_a_cem = "3.8 segundos";
        carro2.cambio = "Automático";
        carro2.info();

        Carro carro3 = new Carro();

        carro3.marca = "Honda";
        carro3.modelo = "Civic Type-R";
        carro3.ano = 2022;
        carro3.cor = "Roxo";
        carro3.cilindro = 4;
        carro3.cavalo = "297 cavalos";
        carro3.velocidade_maxima = "275 km/h";
        carro3.marcha = 6;
        carro3.porta = 4;
        carro3.zero_a_cem = "5.4 segundos";
        carro3.cambio = "Manual";
        carro3.info();

        System.out.println("---=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=---");
        System.out.println(" ");
        carro1.acelerar();
        carro1.frear();
        carro1.mudar();
        System.out.println(" ");
        System.out.println("---=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=---");
        System.out.println(" ");
        carro2.acelerar();
        carro2.frear();
        carro2.mudar();
        System.out.println(" ");
        System.out.println("---=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=---");
        System.out.println(" ");
        carro3.acelerar();
        carro3.frear();
        carro3.mudar();
        System.out.println(" ");
        System.out.println("-------------------------------------------");
    }
}